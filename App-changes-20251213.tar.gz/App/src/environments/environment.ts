export const environment = {
  production: false,
  apiBase: 'http://localhost:7071/api',
  apiKey: 'dev-api-key',
  defaultUserId: '',
};
